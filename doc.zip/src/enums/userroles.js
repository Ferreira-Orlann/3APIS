export const UserRoles = {
    CLIENT: "client",
    EMPLOYEE: "employee",
    ADMIN: "admin"
}