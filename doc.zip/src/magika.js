import { MagikaNode as Magika } from "magika";

export const magika = new Magika()